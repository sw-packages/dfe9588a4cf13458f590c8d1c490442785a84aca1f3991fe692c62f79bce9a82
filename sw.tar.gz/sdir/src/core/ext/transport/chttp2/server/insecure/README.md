Plugin for creating insecure servers using chttp2
